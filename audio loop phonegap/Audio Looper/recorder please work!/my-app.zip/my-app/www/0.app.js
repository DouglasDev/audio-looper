(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[0],{

/***/ "./src/sounds/high.wav":
/*!*****************************!*\
  !*** ./src/sounds/high.wav ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("module.exports = __webpack_require__.p + \"media/high.1bfbd8c.wav\";\n\n//# sourceURL=webpack:///./src/sounds/high.wav?");

/***/ })

}]);