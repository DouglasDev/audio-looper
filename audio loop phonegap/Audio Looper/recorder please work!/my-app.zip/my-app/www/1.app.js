(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[1],{

/***/ "./src/sounds/low.wav":
/*!****************************!*\
  !*** ./src/sounds/low.wav ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("module.exports = __webpack_require__.p + \"media/low.03c97be.wav\";\n\n//# sourceURL=webpack:///./src/sounds/low.wav?");

/***/ })

}]);